n = 267
if n % 3 == 0 and n % 2 == 0:
    print('참')
else:
    print('거짓')