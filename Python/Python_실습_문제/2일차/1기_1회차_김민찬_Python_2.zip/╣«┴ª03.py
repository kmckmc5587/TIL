# 1) while
n = 10
i = 0
sum = 0

while i <= 10:
    sum += i
    i += 1
print(sum)

# 2) for
sum = 0

for i in range(n + 1):
    sum += i
    print(sum)