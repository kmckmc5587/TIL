def rectangle(a, b):
    return a * b, (a + b) * 2

print(rectangle(20, 30))