numbers = [0, 20, 100]

min = 0
for num in numbers:
    if(num <= min):
        min = num
print(min)