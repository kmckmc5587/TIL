numbers = [3, 10, 20]

add = 0
num = 0

for i in numbers:
    add = add + i
    num += 1
print(add/num)