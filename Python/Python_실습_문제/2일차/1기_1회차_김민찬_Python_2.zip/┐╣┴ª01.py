n = int(input())

def cube(n):
    return n ** 3
print(cube(n))